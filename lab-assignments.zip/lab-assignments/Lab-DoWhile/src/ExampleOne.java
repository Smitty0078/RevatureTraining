
public class ExampleOne {

	public static void main(String[] args) {
		boolean on = false;
		
		do 
		{
			System.out.println("inside do while loop");
		}while(on);
		
		

	}

}
