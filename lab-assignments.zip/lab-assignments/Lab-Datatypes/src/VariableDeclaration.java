
public class VariableDeclaration {

	public static void main(String[] args) {
		boolean on = false;
		System.out.println(on);
		
		short s = 16;
		System.out.println(s);
		
		int i = -32;
		System.out.println(i);
		
		float f = 3839.34839f;
		System.out.println(f);
		
		long L = 4_294_967_296L;
		System.out.println(L);
		
		char c = 'a';
		System.out.println(c);

	}

}
