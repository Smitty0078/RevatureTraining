
public class MultidimensionalArrays {

	public static void main(String[] args) {
		int[][][] my3dArray = new int [3][3][3];
		my3dArray[0][0][0] = 1;
		
		System.out.println(my3dArray[0][0][0]);
		

	}

}
